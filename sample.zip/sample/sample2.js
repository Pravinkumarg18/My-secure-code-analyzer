// vulnerable_30.js
// Single-file intentionally vulnerable JS (Node/browser mix).
// Contains exactly 30 distinct issues labeled VULN #1 .. VULN #30.
// For educational/testing purposes only. Do not deploy.

const http = require("http");
const fs = require("fs");
const child_process = require("child_process");
const crypto = require("crypto");
const url = require("url");

// ---------------------------
// VULN #1 - Hardcoded admin credential (single occurrence)
const ADMIN_USERNAME = "admin_v1";
const ADMIN_PASSWORD = "weakpass_v1";

// ---------------------------
// VULN #2 - SQL injection via string concatenation (single occurrence)
function buildQuery_v2(userInput) {
  // vulnerable: concatenating untrusted input into SQL
  return "SELECT * FROM accounts WHERE acct_id=" + userInput;
}

// ---------------------------
// VULN #3 - Command injection via exec (single occurrence)
function runPing_v3(host) {
  // vulnerable: unsanitized concatenation to exec
  child_process.exec("ping -c 1 " + host, (err, stdout) => {
    console.log(stdout || err);
  });
}

// ---------------------------
// VULN #4 - Path traversal reading file (single occurrence)
function readUpload_v4(filename) {
  // vulnerable: direct concatenation allowing ../ traversal
  return fs.readFileSync("uploads/" + filename, "utf8");
}

// ---------------------------
// VULN #5 - Unsafe eval (single occurrence)
function evalUser_v5(code) {
  // vulnerable: executing arbitrary string as code
  return eval(code);
}

// ---------------------------
// VULN #6 - Insecure file upload saving without checks (single occurrence)
function saveUpload_v6(fileObj) {
  // fileObj should have .name and .buffer properties (example)
  fs.writeFileSync("public_uploads/" + fileObj.name, fileObj.buffer);
  return true;
}

// ---------------------------
// VULN #7 - Cross-site scripting (reflected output, single occurrence)
// Example: in a server response we insert raw query param into page
function renderMessage_v7(msg) {
  return `<div>Message: ${msg}</div>`; // vulnerable: no escaping
}

// ---------------------------
// VULN #8 - Open redirect (single occurrence)
function redirect_v8(res, target) {
  // vulnerable: redirects to arbitrary user-controlled URL
  res.writeHead(302, { Location: target });
  res.end();
}

// ---------------------------
// VULN #9 - Insecure random token using Math.random (single occurrence)
function token_v9() {
  // insecure randomness for tokens
  return Math.random().toString(36).slice(2);
}

// ---------------------------
// VULN #10 - Hardcoded API key (single occurrence)
const EXTERNAL_API_KEY_V10 = "APIKEY-V10-EXAMPLE";

// ---------------------------
// VULN #11 - Weak hash for passwords (MD5, single occurrence)
function weakHash_v11(password) {
  return crypto.createHash("md5").update(password).digest("hex");
}

// ---------------------------
// VULN #12 - Insecure JWT secret (single occurrence)
const JWT_SECRET_V12 = "jwt-secret-v12"; // weak and hardcoded

// ---------------------------
// VULN #13 - No CSRF protection (single occurrence)
// naive state-change handler that doesn't check origin or token
function changeEmail_v13(req, res, newEmail) {
  // imagine this runs on POST and changes email without CSRF check
  // vulnerable: no token validation
  res.end("Email changed to " + newEmail);
}

// ---------------------------
// VULN #14 - Using deserialize on untrusted JSON to instantiate objects (single occurrence)
// (illustrative; not using class reviver but still unsafe pattern)
function parseAndUse_v14(serialized) {
  // vulnerable: trusting structure and using it directly
  const obj = JSON.parse(serialized);
  if (obj && obj.action === "run") {
    // dangerous behavior triggered by user-provided object
    child_process.exec(obj.cmd || "");
  }
}

// ---------------------------
// VULN #15 - Disclosure: printing stack traces to users (single occurrence)
function errorHandler_v15(res, err) {
  // vulnerable: leaking internal error details to response
  res.end("Error: " + err.stack);
}

// ---------------------------
// VULN #16 - Insecure cookie with no flags (single occurrence)
function setAuthCookie_v16(res, value) {
  // vulnerable: missing HttpOnly / Secure / SameSite
  res.setHeader("Set-Cookie", "auth_v16=" + value + "; Path=/");
}

// ---------------------------
// VULN #17 - JSONP-like callback without validation (single occurrence)
function jsonp_v17(res, callback, data) {
  // vulnerable: executing arbitrary callback name
  res.end(`${callback}(${JSON.stringify(data)})`);
}

// ---------------------------
// VULN #18 - Server-Side Request Forgery (SSRF) via fetch without validation (single occurrence)
const httpGet_v18 = (targetUrl, cb) => {
  // vulnerable: allowing user-specified URL to be requested
  http.get(targetUrl, (resp) => {
    let body = "";
    resp.on("data", (chunk) => (body += chunk));
    resp.on("end", () => cb(null, body));
  }).on("error", (e) => cb(e));
};

// ---------------------------
// VULN #19 - Prototype pollution via Object.assign with user payload (single occurrence)
function mergeVuln_v19(target, userPayload) {
  // vulnerable: direct merging can pollute prototypes
  return Object.assign(target, userPayload);
}

// ---------------------------
// VULN #20 - Insecure deserialization via Function constructor (single occurrence)
function functionFromString_v20(code) {
  // vulnerable: creating function from user-supplied string
  const fn = new Function(code);
  return fn();
}

// ---------------------------
// VULN #21 - Logging sensitive data (single occurrence)
function login_v21(username, password) {
  // vulnerable: logging credentials
  console.log("Login attempt:", username, password);
  return username === ADMIN_USERNAME && password === ADMIN_PASSWORD;
}

// ---------------------------
// VULN #22 - No input validation leading to ReDoS (single occurrence)
function vulnerableRegex_v22(input) {
  // catastrophic backtracking potential with certain inputs
  return /^([a-zA-Z]+)+$/.test(input);
}

// ---------------------------
// VULN #23 - Insecure storage: writing secrets to world-readable file (single occurrence)
function storeSecret_v23(secretContent) {
  // vulnerable: writing secret to a publicly readable location
  fs.writeFileSync("secrets/public_secret_v23.txt", secretContent, { mode: 0o644 });
}

// ---------------------------
// VULN #24 - Insecure file write with race condition (single occurrence)
function incrementCounter_v24() {
  // vulnerable: read-modify-write with no lock
  let v = parseInt(fs.readFileSync("counter_v24.txt", "utf8") || "0", 10);
  v += 1;
  fs.writeFileSync("counter_v24.txt", String(v));
  return v;
}

// ---------------------------
// VULN #25 - Exposing filesystem path (single occurrence)
function showPath_v25(res) {
  // vulnerable: revealing server path
  res.end("Server path: " + __dirname);
}

// ---------------------------
// VULN #26 - Weak HMAC key usage (single occurrence)
function sign_v26(data) {
  // vulnerable: very short static key and old algorithm usage
  return crypto.createHmac("sha1", "k26").update(data).digest("hex");
}

// ---------------------------
// VULN #27 - Using eval-like HTML insertion in browser (single occurrence)
// (This function is for front-end usage; shows innerHTML usage)
function insertHtml_v27(container, userHtml) {
  // vulnerable: inserting raw HTML
  container.innerHTML = userHtml;
}

// ---------------------------
// VULN #28 - Open directory listing (single occurrence)
function listDir_v28(res) {
  const items = fs.readdirSync(".");
  res.end(items.join("\n"));
}

// ---------------------------
// VULN #29 - Missing rate limiting (single occurrence)
let attempts_v29 = 0;
function attempt_v29() {
  // vulnerable: no throttling
  attempts_v29++;
  return attempts_v29;
}

// ---------------------------
// VULN #30 - Unsafe header injection (CRLF not sanitized, single occurrence)
function setCustomHeader_v30(res, value) {
  // vulnerable: value may contain CRLF and split headers
  res.setHeader("X-Custom-Header", value);
}

// ---------------------------
// Minimal demo server exposing some of the above (for local tests only)
// Note: Not all functions are wired into routes — they're present as distinct vuln instances.
const server = http.createServer((req, res) => {
  const q = url.parse(req.url, true).query;
  if (q.p === "ping") {
    runPing_v3(q.host || "127.0.0.1");
    res.end("ping triggered");
    return;
  }
  if (q.p === "read") {
    try {
      res.end(readUpload_v4(q.file || "none"));
    } catch (e) {
      res.end("error");
    }
    return;
  }
  if (q.p === "render") {
    res.end(renderMessage_v7(q.msg || ""));
    return;
  }
  if (q.p === "redir") {
    redirect_v8(res, q.to || "/");
    return;
  }
  if (q.p === "list") {
    listDir_v28(res);
    return;
  }
  if (q.p === "path") {
    showPath_v25(res);
    return;
  }
  // default response
  res.end("vulnerable_30 demo");
});

server.listen(9876, () => {
  console.log("vulnerable_30 server listening on http://localhost:9876");
});
